package cucumber.feature;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MyStudentClass 
{
	@Given("^hi dhrona$")
	public void hi_dhrona() throws Throwable 
	{
		System.out.println("This is dhrona logic");
	    
	}

	@When("^hi sir$")
	public void hi_sir() throws Throwable 
	{
	    System.out.println("This is my logic");
	}

	@Then("^This is my cucumber class$")
	public void this_is_my_cucumber_class() throws Throwable
	{
		System.out.println("This is my student class");
	    
	}



}
