package cucumber.feature;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GmailLogin 
{
	WebDriver d=new FirefoxDriver();
	
	@Given("^we can open website$")
	public void we_can_open_website() throws Throwable 
	{
		Thread.sleep(2000);
	    d.get("http://www.google.com");
	}

	@When("^we can click on gmaillink$")
	public void we_can_click_on_gmaillink() throws Throwable 
	{
		Thread.sleep(2000);
		d.findElement(By.id("gb_70")).click();
	    
	}

	@When("^Give email id$")
	public void give_email_id() throws Throwable 
	{
		Thread.sleep(2000);
	    d.findElement(By.id("Email")).sendKeys("umadevich1212@gmail.com");
	}

	@When("^click on next$")
	public void click_on_Next() throws Throwable 
	{
		Thread.sleep(2000);
	    d.findElement(By.id("next")).click();
	}

	@When("^Enter password$")
	public void enter_password() throws Throwable
	{
		Thread.sleep(2000);
	    d.findElement(By.id("Passwd")).sendKeys("uma@1987");

		Thread.sleep(2000);
	    d.findElement(By.xpath(".//*[@id='signIn']")).click();
	}
	
	/*@When("^Click on next$")
	public void click_on_next() throws Throwable
	{
		Thread.sleep(5000);
		 
	}*/

	@When("^click on gmail link$")
	public void click_on_gmail_link() throws Throwable 
	{
		Thread.sleep(2000);
	   d.findElement(By.linkText("Gmail")).click();
	}

	@Then("^open website$")
	public void open_website() throws Throwable
	{
	    System.out.println("Login Successful...");
	}



}
