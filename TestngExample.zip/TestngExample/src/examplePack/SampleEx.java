package examplePack;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class SampleEx
{
	@Test(dataProvider="mydata")
	//public void Display(String n1, String n2)
	//{
	//	System.out.println(n1+ "" +n2);
	//}
	
	public void Display(String eno, String ename, String salary)
	{
		System.out.println(eno+ "," +ename+ "," +salary);
		System.out.println(""); // background loop will create automatically
	}
	@DataProvider(name="mydata")
	public Object[][] GetDetails()
	{
		//String name1="Mahesh";
		//String name2="Raju";
		
		//String[][] data=new String[1][2];
		//data[0][0]=name1;
		//data[0][1]=name2;
		
		String[][] data=new String[3][3];
		
		data[0][0]="100";
		data[0][1]="Raju";
		data[0][2]="25000";
		
		data[1][0]="200";
		data[1][1]="Ramu";
		data[1][2]="35000";
		
		data[2][0]="300";
		data[2][1]="Raghu";
		data[2][2]="45000";
		
		return data;
	}

}
