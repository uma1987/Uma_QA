package examplePack;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestngEx 
{
	//@Test(priority=1)
	@BeforeMethod
	public void Login()
	{
		System.out.println("Login successful...");
	}
	//@Test(enabled=false)
	@Test(priority=1)
	public void WithDraw()
	{
		System.out.println("WithDraw successful...");
		
	}
	@Test(priority=2)
	public void Deposit()
	{
		System.out.println("Deposit successful...");
	}
	//@Test(priority=4)
	 @AfterMethod
	public void Logout()
	{
		System.out.println("Logout successful...");
	}

}
