package examplePack;
import java.io.File;
import java.io.IOException;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


public class Excel
{
	
		@Test(dataProvider="mydata")
		public void Display(String eno, String ename, String salary)
		{
			System.out.println(eno+ "," +ename+ "," +salary);
			System.out.println(""); // background loop will create automatically
		}
		@DataProvider(name="mydata")
		public Object[][] GetDetails() throws BiffException, IOException
		{
			//open file
			File f=new File("D:\\MyData.xls");
			Workbook wb=Workbook.getWorkbook(f);
			
			Sheet sh=wb.getSheet(0);
			
			//get the used row and column count
			int rcount=sh.getRows();
			int ccount=sh.getColumns();
			
			//Row loop
			String[][] data=new String[rcount][ccount]; //array string
			
			for(int r=1;r<rcount;r++)
			{
				for(int c=1;c<ccount;c++)
				{
					Cell myvalue=sh.getCell(c,r);
					String value=myvalue.getContents();
					data[r][c]=value;
				}
			}
			return data;
		}

	}


