package gmailPack;

import java.io.IOException;

import jxl.read.biff.BiffException;

import org.testng.annotations.Test;

public class ExecutionClass
{
	@Test(priority=1)
	public void FinalProcess() throws BiffException, IOException, InterruptedException
	{
		//Open Excelsheet
		ExcelsheetProcess mysheet=new ExcelsheetProcess();
		String path="D:\\Keyboardtestdata.xls";
		mysheet.OpenSheet(path);
		
		//get rowcount
		int rcount=mysheet.Rowcount();
		int ccount=mysheet.ColumnCount();
		
		System.out.println("Row count: "+rcount);
		System.out.println("Column count: "+ccount);
		
		//declare four variables
		String tname="";
		String ptype="";
		String pvalue="";
		String tdata="";
		
		//Create the testcase function object
		TestcaseProcess tobj=new TestcaseProcess();
		
		//Excel sheet loop
		for(int r=1;r<rcount;r++)
		{
			//Get Test case name
			tname=mysheet.GetValueFromCell(r, 0);
			
			//Get ptype,pvalue,tdata
			for(int c=1;c<ccount;c++)
			{
				if(c==1)
				{
					ptype=mysheet.GetValueFromCell(r, c);
				}
				else if(c==2)
				{
					pvalue=mysheet.GetValueFromCell(r, c);
				}
				else if(c==3)
				{
					tdata=mysheet.GetValueFromCell(r, c);
					
				}
			}
			System.out.println(tname + " " +ptype + " " +pvalue+ " " +tdata);
			Thread.sleep(3000);
			switch(tname)
			{
			case "Open_Browser":
				tobj.Open_Browser(tdata);
				break;
			case "Open_Url":
				tobj.Open_Url(tdata);
				break;
			case "Click_Link":
				tobj.Click_Link(ptype,pvalue);
				break;
			case "Enter_Text":
				tobj.Enter_Text(ptype, pvalue, tdata);
				break;
			case "Click_Button":
			tobj.Click_Button(ptype, pvalue);
				break;
			case "Close_Browser":
				tobj.Close_Browser();
				break;
			default:
				System.out.println("no test case");
				break;
			}
			
			}
		}
		
	}


