package gmailPack;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class TestcaseProcess
{
	static WebDriver d;
	public void Open_Browser(String tdata)
	{
		if(tdata.equalsIgnoreCase("Firefox"))
		{
			d=new FirefoxDriver();
		}
		else if(tdata.equalsIgnoreCase("Chrome"))
		{
			d=new ChromeDriver();
		}
		else if(tdata.equalsIgnoreCase("IE"))
		{
			d= new InternetExplorerDriver();
		}
				
	}
	
	public void Open_Url(String tdata)
	{
		d.get(tdata);
		
	}
	
	public void Click_Link(String ptype, String pvalue)
	{
		By e=weblocators(ptype,pvalue);
		d.findElement(e).click();
		
		
	}
	
	public void Enter_Text(String ptype, String pvalue, String tdata)
	{
		By e=weblocators(ptype,pvalue);
		d.findElement(e).sendKeys(tdata);
		
		
	}
	
	public void Click_Button(String ptype, String pvalue)
	{
		By e=weblocators(ptype,pvalue);
		d.findElement(e).click();
		
	}
	
	public void Close_Browser()

	{
		d.close();
		
	}
	public By weblocators(String ptype, String pvalue)
	{
		By b;
		switch(ptype)
		{
		case "id":
			b=By.id(pvalue);
			break;
		case "name":
			b=By.name(pvalue);
			break;
		case "xpath":
			b=By.xpath(pvalue);
			break;
		case "linkText":
			b=By.linkText(pvalue);
			break;
		case "css":
			b=By.cssSelector(pvalue);
			break;
		default:
			b=null;
			break;
		}
		return b;
			
			
		}
		
	}








