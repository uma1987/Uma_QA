package samplePack;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseoverActionExample 
{
	public static void main(String args[]) throws InterruptedException
	{
		//open webdriver
		
		WebDriver d= new FirefoxDriver();
		
		//open site
		d.get("http://store.demoqa.com");
		
		//select product category
		//d.findElement(By.linkText("Product Category")).click();
		
		WebElement e=d.findElement(By.linkText("Product Category"));
		
		Actions a=new Actions(d);
		
		a.moveToElement(e).build().perform();
		
		Thread.sleep(5000);
		d.findElement(By.linkText("iPads")).click();
		
		
	}
}
