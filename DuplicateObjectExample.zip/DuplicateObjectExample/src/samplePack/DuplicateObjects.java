package samplePack;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DuplicateObjects {

	public static void main(String[] args) throws InterruptedException 
	{
		WebDriver d=new FirefoxDriver();
		
		d.get("http://www.infibeam.com");
		
		//click on login link
		Thread.sleep(5000);
		d.findElement(By.id("loginlink")).click();
		
		//click on create account
		
		Thread.sleep(5000);
		d.findElement(By.id("new-account-btn")).click();
		
		//select password textbox
		List<WebElement> e=d.findElements(By.id("password"));
		
		e.get(0).sendKeys("hi");
		e.get(1).sendKeys("hello");

	}

}
