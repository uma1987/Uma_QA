package samplePack;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class TestExample {

	public static void main(String[] args) throws InterruptedException 
	{
		//open firefox
		
	WebDriver f= new FirefoxDriver();
	Thread.sleep(7000);
		f.get("http://www.facebook.com");
		
		Thread.sleep(7000);
		
		f.navigate().to("http://www.youtube.com");
		
		Thread.sleep(7000);
		
		f.navigate().back();
		Thread.sleep(7000);
		f.navigate().forward();
		
		
		//open chrome
		//Thread.sleep(7000);
		//System.setProperty("webdriver.chrome.driver", "‪D:\\chromedriver_win32\\chromedriver.exe");
		
		//WebDriver c=new ChromeDriver();
	///	c.get("http://www.google.com");
		
		//open internet explorer
		//Thread.sleep(7000);
		//System.setProperty("webdriver.ie.driver", "D:\\IEDriverServer_Win32_2.53.1\\IEDriverServer.exe");
		//WebDriver i=new InternetExplorerDriver();
		//i.get("http://www.google.com");
		
	
		

	}

}
