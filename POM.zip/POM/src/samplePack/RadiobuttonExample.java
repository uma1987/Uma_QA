package samplePack;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class RadiobuttonExample {
	
	public static void main(String args[]) throws InterruptedException
	{
		//create the webdriver
		WebDriver d=new FirefoxDriver();
		
		//open url
		
		Thread.sleep(5000);
		d.get("http://newtours.demoaut.com");
		
		//enter username
		Thread.sleep(5000);
		
		d.findElement(By.name("userName")).sendKeys("mahesh");
		
		//enter password
		Thread.sleep(5000);
		d.findElement(By.name("password")).sendKeys("mahesh");
		
		//click on sign in
		Thread.sleep(5000);
		d.findElement(By.name("login")).click();
		
		//handling the one way radiobutton
		
		//d.findElement(By.xpath("html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[2]/td[2]/b/font/input[1]")).click();
		
		
		//get the attribute names
		String r1=d.findElement(By.xpath("html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[2]/td[2]/b/font/input[2]")).getAttribute("value");
	
		System.out.println("Radiobuttonname:" + r1);
		
		//handling round trip Radiobutton
		
		//d.findElement(By.xpath("html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[2]/td[2]/b/font/input[1]")).click();
		
		//get the attribute names
		String r2=d.findElement(By.xpath("html/body/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr/td[2]/table/tbody/tr[5]/td/form/table/tbody/tr[2]/td[2]/b/font/input[1]")).getAttribute("value");
	     
		System.out.println("Radiobutton name:" + r2);
	}
	
	

}
