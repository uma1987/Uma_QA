package samplePack;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class DropDownListExample 
{
	public static void main(String args[]) throws InterruptedException
	{
	
	//create the webdriver
			WebDriver d=new FirefoxDriver();
			
			//open url
			
			Thread.sleep(5000);
			d.get("http://newtours.demoaut.com");
			
			//enter username
			Thread.sleep(5000);
			
			d.findElement(By.name("userName")).sendKeys("mahesh");
			
			//enter password
			Thread.sleep(5000);
			d.findElement(By.name("password")).sendKeys("mahesh");
			
			//click on sign in
			Thread.sleep(5000);
			d.findElement(By.name("login")).click();
			
			//select dropdownlist
			d.findElement(By.name("fromPort")).click();
			
			//select dropdown list options
			
			//get all the list of options store in select class object
			
			Select drp=new Select(d.findElement(By.name("fromPort")));
			
			Thread.sleep(5000);
			drp.selectByValue("London");
			
			Thread.sleep(5000);
			drp.selectByIndex(5);
			
			
			

}
}
