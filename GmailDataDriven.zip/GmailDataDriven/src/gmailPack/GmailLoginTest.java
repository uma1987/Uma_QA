package gmailPack;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class GmailLoginTest 
{
	@Test(priority=1)
	public void GmailLogin() throws InterruptedException
	{
		//Open Driver
		WebDriver d=new FirefoxDriver();
		
		//Open URL
		Thread.sleep(4000);
		d.get("https://www.google.co.in/?gws_rd=ssl");
		
		//click on sign in
		Thread.sleep(4000);
		d.findElement(By.id("gb_70")).click();
		
		//send the email id to the text box
		Thread.sleep(4000);
		d.findElement(By.id("Email")).sendKeys("umadevich1212@gmail.com");
		
		//click on next button
		Thread.sleep(4000);
		d.findElement(By.id("next")).click();
		
		//send password
		Thread.sleep(4000);
		d.findElement(By.id("Passwd")).sendKeys("uma@1987");
		
		//click on signin
		Thread.sleep(4000);
		d.findElement(By.id("signIn")).click();
		
		//click on gmail
		Thread.sleep(4000);
		d.findElement(By.linkText("Gmail")).click();
		
		//click on profile picture
		Thread.sleep(4000);
		d.findElement(By.xpath(".//*[@id='gb']/div[1]/div[1]/div[2]/div[4]/div[1]/a/span")).click();
		
		//click on sign out button
		Thread.sleep(4000);
		d.findElement(By.id("gb_71")).click();
		
		//close browser
		Thread.sleep(4000);
		d.close();
	}

}
