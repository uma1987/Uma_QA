package loginpack;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class GmailTestClass {

	public static void main(String[] args) throws InterruptedException {
		//create the webdriver
		WebDriver d= new FirefoxDriver();
		
		//give url
		Thread.sleep(4000);
		d.get("http://www.google.co.in");

		//click on sign in
		Thread.sleep(4000);
		d.findElement(By.id("gb_70")).click();
		
		//type the email
		Thread.sleep(4000);
		d.findElement(By.id("Email")).sendKeys("umadevich1212@gmail.com");
		
		//click on next
		Thread.sleep(4000);
		d.findElement(By.id("next")).click();
		
		//type the password
		Thread.sleep(4000);
		d.findElement(By.id("Passwd")).sendKeys("uma@1987");
		
		//click on sign in button
		Thread.sleep(4000);
		d.findElement(By.id("signIn")).click();
		
		//click on gmail
		Thread.sleep(4000);
		d.findElement(By.linkText("Gmail")).click();

	}

}
